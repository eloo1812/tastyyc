<?php
namespace app\controllers;

use app\traits\Template;

abstract class Base 
{
    use Template;   
}