<?php
namespace app\database\models;
use PDO;

class Usuario extends Base
{
    protected $table = "usuarios";

    
}