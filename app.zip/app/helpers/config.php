<?php
namespace app\helpers;

define('ROOT', dirname(__FILE__, 3));
define('DIR_VIEWS', ROOT . '/app/views/');
define('EXT_VIEWS', '.html');
